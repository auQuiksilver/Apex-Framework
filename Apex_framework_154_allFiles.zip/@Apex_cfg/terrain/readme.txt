






	We are adding improved support for terrains (WIP).

	This means allowing admins and designers to set up different Arsenal configurations based on what terrain is being played (with DLC weapons for instance).

	We have set up folders for each supported terrain.

	If there is no folder for the specific terrain, the main file will be used.

	We have not added folders for vanilla terrains in order to not affect existing content, however simply creating the folder and files within will plug into the system.
	
	Use existing examples as a reference.

	The terrain folders can be safely deleted if they are not necessary, the main files will be used.
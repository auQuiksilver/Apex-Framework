26/01/2018 A3 1.80

- These are mission.SQM files for using on the supported terrains.

- The default folder contains mission.SQM files for use with the default base layout (selectable in the @Apex_cfg\parameters.sqf file).

- The custom folder contains mission.SQM files for use with custom base layouts. It comes with the required map markers, some scripted entities and examples of respawnable vehicles and arsenals.